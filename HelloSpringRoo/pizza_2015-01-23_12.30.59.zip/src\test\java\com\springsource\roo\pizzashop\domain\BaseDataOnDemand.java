package com.springsource.roo.pizzashop.domain;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Base.class)
public class BaseDataOnDemand {
}
